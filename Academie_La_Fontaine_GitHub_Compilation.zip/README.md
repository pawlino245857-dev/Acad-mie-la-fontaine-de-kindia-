# Académie La Fontaine — Version 2

Cette version prépare une vraie application publique avec :
- base de données en ligne Supabase ;
- connexion administrateur par email + mot de passe ;
- joueurs, actualités, matchs et classement modifiables ;
- lecture publique pour tous ;
- logo officiel fourni par l'académie.

## Mise en ligne
1. Créer un projet gratuit sur Supabase.
2. Ouvrir SQL Editor et exécuter `supabase_schema.sql`.
3. Créer un utilisateur administrateur dans Authentication > Users.
4. Dans `index.html`, remplacer `YOUR_SUPABASE_URL` et `YOUR_SUPABASE_ANON_KEY` par les valeurs du projet Supabase.
5. Héberger le dossier sur Netlify, Vercel, GitHub Pages (avec adaptation si nécessaire) ou un autre hébergeur HTTPS.

## Important
Je ne peux pas créer le compte Supabase à ta place ni inventer tes clés d'accès. Une fois ces deux valeurs fournies/configurées, les changements effectués par l'administrateur sont stockés en ligne et visibles par les utilisateurs.

Pour une vraie publication Google Play, il faudra ensuite emballer cette PWA en application Android (par exemple avec Capacitor) et préparer la fiche Play Store.
