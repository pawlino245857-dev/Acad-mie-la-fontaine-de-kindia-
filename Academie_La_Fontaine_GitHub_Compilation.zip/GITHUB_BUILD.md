# Compilation Android

Le workflow GitHub Actions se lance automatiquement après un push sur `main` ou `master`, ou manuellement depuis l'onglet Actions avec `Build Android` > `Run workflow`.

Le résultat de cette première compilation est un APK de test téléchargeable dans les Artifacts.

Pour Google Play, il faudra ensuite configurer une signature de production et générer un `.aab`. Ne partagez jamais une clé privée de signature ou un mot de passe dans le dépôt.
