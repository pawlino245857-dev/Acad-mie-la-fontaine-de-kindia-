import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.academielafontaine.kindia',
  appName: 'Académie La Fontaine de Kindia',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
