# Académie La Fontaine de Kindia — préparation Android

Cette version contient l'application web dans `www/` et la configuration Capacitor.

## Étapes sur un ordinateur
1. Installer Node.js LTS et Android Studio.
2. Dans ce dossier : `npm install`
3. Initialiser Capacitor si nécessaire : `npx cap add android`
4. Synchroniser : `npx cap sync android`
5. Ouvrir Android Studio : `npx cap open android`
6. Générer un Android App Bundle signé (`.aab`) pour Google Play.

Identifiant Android : `com.academielafontaine.kindia`
Nom : Académie La Fontaine de Kindia

Ne mettez jamais une clé Supabase SECRET dans l'application. Seule la clé publishable/anon peut être côté client, avec les politiques RLS correctement configurées.
