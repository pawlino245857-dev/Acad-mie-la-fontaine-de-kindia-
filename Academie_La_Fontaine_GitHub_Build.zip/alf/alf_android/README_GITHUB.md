# Compilation Android en ligne

Le workflow `.github/workflows/android-build.yml` permet de compiler ce projet sur GitHub Actions depuis un téléphone.

Le résultat est un fichier `.aab` de release. Avant une publication Google Play, il faudra mettre en place une signature de production adaptée.
